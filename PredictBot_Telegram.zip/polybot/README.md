# 🎯 PredictBot — Telegram Prediction Market Bot

A clean, fair, educational prediction market bot.
Users deposit via UPI → get Points → predict Yes/No on markets.

---

## ⚡ QUICK SETUP (15 minutes, completely FREE)

### STEP 1 — Get Your Bot Token from @BotFather

1. Open Telegram → search **@BotFather**
2. Send `/newbot`
3. Enter a name: e.g. `My Predict Bot`
4. Enter a username: e.g. `mypredictbot` (must end in "bot")
5. BotFather gives you a token like:
   `5823749821:AAFjk2nD9s_xKFakeTokenExample123`
6. **Copy this token — you need it below**

---

### STEP 2 — Get Your Admin Telegram ID

1. Open Telegram → search **@userinfobot**
2. Send `/start`
3. It replies with your numeric ID like `829374651`
4. **Copy this number**

---

### STEP 3 — Deploy FREE on Railway.app

**Railway gives you free hosting forever for small bots.**

1. Go to **https://railway.app** → Sign up with GitHub (free)
2. Click **"New Project"** → **"Deploy from GitHub repo"**
3. Upload your code to a GitHub repo (or use Railway's template)

   **To push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Initial bot"
   git branch -M main
   git remote add origin https://github.com/YOURUSERNAME/predictbot.git
   git push -u origin main
   ```

4. In Railway, after connecting your repo:
   - Go to **Variables** tab
   - Add these 3 variables:
     ```
     BOT_TOKEN   = (paste your bot token)
     ADMIN_ID    = (paste your numeric ID)
     UPI_ID      = yourname@paytm
     ```
5. Railway auto-deploys. Your bot is LIVE! ✅

---

### STEP 4 — Alternative: Run on Your PC (for testing)

```bash
# Install Python 3.10+, then:
pip install -r requirements.txt

# Create .env file
cp .env.example .env
# Edit .env and fill in BOT_TOKEN, ADMIN_ID, UPI_ID

# Run
python bot.py
```

---

## 🤖 BOT COMMANDS

### User Commands
| Command | Description |
|---------|-------------|
| `/start` | Welcome message + main menu |
| `/markets` | View all open prediction markets |
| `/deposit` | Deposit via UPI to get points |
| `/balance` | Check your wallet balance |
| `/history` | View your bets and deposits |
| `/leaderboard` | Top 10 predictors |
| `/help` | Help guide |

### Admin Commands (only you can use these)
| Command | Example | Description |
|---------|---------|-------------|
| `/admin` | `/admin` | Admin dashboard with stats |
| `/create_market` | `/create_market Will India win?|YES|NO` | Create new market |
| `/resolve` | `/resolve 3 YES` | Resolve market #3 as YES |
| `/give_points` | `/give_points 829374651 100` | Give 100 pts to user |
| `/all_deposits` | `/all_deposits` | See all pending deposits |
| `/all_users` | `/all_users` | See all users + balances |

---

## 💡 HOW IT WORKS

```
User deposits ₹50 via UPI
    ↓
Sends UTR (transaction ID) to bot
    ↓
Bot notifies Admin with [Approve] [Reject] buttons
    ↓
Admin clicks Approve → 50 points added to user
    ↓
User bets 20 points on "YES" in a market
    ↓
Admin runs /resolve 1 YES
    ↓
Bot calculates payout: (20 / total_yes_pool) × total_pool
    ↓
Winner gets points, loser loses their bet
```

### Payout Formula
```
Payout = (Your Bet / Total Winning Side Pool) × Total Market Pool
```
Example:
- Total pool = 100 pts (60 YES, 40 NO)
- Result = YES
- You bet 30 pts on YES
- Your payout = (30/60) × 100 = **50 pts** (profit: 20 pts!)

---

## 🗄️ DATABASE TABLES

| Table | Purpose |
|-------|---------|
| `users` | User accounts, balances |
| `markets` | Prediction questions |
| `bets` | All bets placed |
| `deposits` | UPI deposit requests |
| `txn_log` | Full audit trail |

---

## 🔒 SAFETY FEATURES

- ✅ Duplicate UTR detection (prevents re-use)
- ✅ Balance check before placing bet
- ✅ Admin approval required for all deposits
- ✅ Full transaction log for audit
- ✅ Admin-only market creation and resolution
- ✅ Minimum deposit limit (₹10)

---

## ⚠️ DISCLAIMER

This bot is for **educational purposes only**.
Points have no monetary value and cannot be withdrawn.
No gambling is involved — this is a points-based prediction game.

---

## 📁 FILE STRUCTURE

```
polybot/
├── bot.py            ← Main bot code (all-in-one)
├── requirements.txt  ← Python dependencies
├── Procfile          ← For Railway/Heroku deployment
├── .env.example      ← Config template
└── README.md         ← This file
```
