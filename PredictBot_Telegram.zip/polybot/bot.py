"""
╔══════════════════════════════════════════════════════════╗
║   POLYMARKET-STYLE PREDICTION BOT  — Educational Use    ║
║   Points-only system (UPI deposit → points, no payout)  ║
╚══════════════════════════════════════════════════════════╝
"""

import logging, sqlite3, os, re
from datetime import datetime
from telegram import (Update, InlineKeyboardButton, InlineKeyboardMarkup,
                       ReplyKeyboardMarkup, KeyboardButton)
from telegram.ext import (ApplicationBuilder, CommandHandler, MessageHandler,
                           CallbackQueryHandler, ContextTypes, filters,
                           ConversationHandler)

# ── Config ────────────────────────────────────────────────────────────────────
BOT_TOKEN   = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
ADMIN_ID    = int(os.getenv("ADMIN_ID", "0"))          # your Telegram numeric ID
UPI_ID      = os.getenv("UPI_ID",  "yourname@upi")    # your UPI address shown to users
POINTS_RATE = 1   # 1 rupee = 1 point
MIN_DEPOSIT = 10  # minimum ₹10

DB = "polybot.db"
logging.basicConfig(level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# Conversation states
(AWAIT_NAME, AWAIT_AMOUNT, AWAIT_UTR, AWAIT_PRED_CHOICE,
 AWAIT_WITHDRAW_AMT) = range(5)

# ── Database ──────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id     INTEGER PRIMARY KEY,
            username    TEXT,
            full_name   TEXT,
            points      REAL    DEFAULT 0,
            total_deposited REAL DEFAULT 0,
            joined_at   TEXT    DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS markets (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            question    TEXT    NOT NULL,
            option_yes  TEXT    DEFAULT 'YES',
            option_no   TEXT    DEFAULT 'NO',
            pool_yes    REAL    DEFAULT 0,
            pool_no     REAL    DEFAULT 0,
            status      TEXT    DEFAULT 'open',   -- open / resolved / cancelled
            result      TEXT,                     -- YES / NO
            created_by  INTEGER,
            created_at  TEXT    DEFAULT (datetime('now')),
            closes_at   TEXT
        );
        CREATE TABLE IF NOT EXISTS bets (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            market_id   INTEGER,
            choice      TEXT,
            points      REAL,
            payout      REAL    DEFAULT 0,
            status      TEXT    DEFAULT 'pending', -- pending / won / lost
            placed_at   TEXT    DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS deposits (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            amount_inr  REAL,
            points      REAL,
            utr         TEXT,
            status      TEXT    DEFAULT 'pending', -- pending / approved / rejected
            requested_at TEXT   DEFAULT (datetime('now')),
            processed_at TEXT
        );
        CREATE TABLE IF NOT EXISTS txn_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            type        TEXT,    -- deposit / bet / payout / refund
            amount      REAL,
            note        TEXT,
            ts          TEXT     DEFAULT (datetime('now'))
        );
        """)
    log.info("Database initialised ✅")

# ── Helpers ───────────────────────────────────────────────────────────────────
def get_user(user_id):
    with get_db() as db:
        return db.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()

def ensure_user(update: Update):
    u = update.effective_user
    with get_db() as db:
        existing = db.execute("SELECT * FROM users WHERE user_id=?", (u.id,)).fetchone()
        if not existing:
            db.execute(
                "INSERT OR IGNORE INTO users (user_id, username, full_name) VALUES (?,?,?)",
                (u.id, u.username or "", u.full_name or u.first_name))
    return get_user(u.id)

def add_points(user_id, pts, txn_type, note=""):
    with get_db() as db:
        db.execute("UPDATE users SET points = points + ? WHERE user_id=?", (pts, user_id))
        db.execute("INSERT INTO txn_log(user_id,type,amount,note) VALUES(?,?,?,?)",
                   (user_id, txn_type, pts, note))

def fmt_pts(p): return f"🪙 {p:,.1f} pts"

def odds_display(pool_yes, pool_no):
    total = pool_yes + pool_no
    if total == 0:
        return 50.0, 50.0
    return round((pool_yes/total)*100, 1), round((pool_no/total)*100, 1)

def market_card(m):
    py, pn = odds_display(m['pool_yes'], m['pool_no'])
    total  = m['pool_yes'] + m['pool_no']
    status_emoji = {"open":"🟢","resolved":"🔴","cancelled":"⚫"}.get(m['status'],"❓")
    result_line = f"\n✅ Result: **{m['result']}**" if m['result'] else ""
    return (
        f"{status_emoji} *Market #{m['id']}*\n"
        f"❓ {m['question']}\n\n"
        f"📊 *Odds*\n"
        f"  ✅ {m['option_yes']}: {py}%  |  ❌ {m['option_no']}: {pn}%\n"
        f"💰 Total Pool: {fmt_pts(total)}{result_line}\n"
        f"🕐 Status: {m['status'].upper()}"
    )

# ── /start & Main Menu ────────────────────────────────────────────────────────
MAIN_KB = ReplyKeyboardMarkup([
    ["📊 Markets", "💰 Deposit"],
    ["👛 My Balance", "📜 History"],
    ["🏆 Leaderboard", "🆘 Help"],
], resize_keyboard=True)

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = ensure_user(update)
    user = update.effective_user
    welcome = (
        f"👋 Welcome *{user.first_name}*!\n\n"
        f"🎯 *PredictBot* — Prediction Market\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📌 Deposit via UPI → Get Points\n"
        f"📌 Use points to predict Yes/No on markets\n"
        f"📌 Win more points if you're right!\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"⚠️ *Educational purpose only. Points have no monetary value.*\n\n"
        f"Your balance: {fmt_pts(u['points'])}\n\n"
        f"Choose an option below 👇"
    )
    await update.message.reply_text(welcome, parse_mode="Markdown",
                                    reply_markup=MAIN_KB)

async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = (
        "🆘 *PredictBot Help*\n\n"
        "📊 *Markets* — View all active prediction markets\n"
        "💰 *Deposit* — Add points via UPI payment\n"
        "👛 *My Balance* — See your current balance\n"
        "📜 *History* — View your bet history & deposits\n"
        "🏆 *Leaderboard* — Top predictors\n\n"
        "*How it works:*\n"
        "1️⃣ Deposit ₹10+ via UPI → Points added to wallet\n"
        "2️⃣ Browse open markets and place prediction\n"
        "3️⃣ Admin resolves market → Winners get paid out\n\n"
        "*Payout formula:*\n"
        "`Your payout = (Your bet / Winning pool) × Total pool`\n\n"
        "⚠️ Points are for entertainment/education only."
    )
    await update.message.reply_text(text, parse_mode="Markdown")

# ── Balance ───────────────────────────────────────────────────────────────────
async def cmd_balance(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = ensure_user(update)
    with get_db() as db:
        active_bets = db.execute(
            "SELECT COUNT(*), COALESCE(SUM(points),0) FROM bets "
            "WHERE user_id=? AND status='pending'", (u['user_id'],)).fetchone()
    text = (
        f"👛 *Your Wallet*\n"
        f"━━━━━━━━━━━━━━\n"
        f"💰 Available: {fmt_pts(u['points'])}\n"
        f"🔒 In Bets:   {fmt_pts(active_bets[1])}\n"
        f"📥 Total Deposited: ₹{u['total_deposited']:,.0f}\n"
        f"🎯 Active Bets: {active_bets[0]}\n"
        f"━━━━━━━━━━━━━━"
    )
    await update.message.reply_text(text, parse_mode="Markdown")

# ── Deposit Flow ──────────────────────────────────────────────────────────────
async def cmd_deposit(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = (
        f"💰 *Deposit Points*\n\n"
        f"1 Rupee = 1 Point\n"
        f"Minimum deposit: ₹{MIN_DEPOSIT}\n\n"
        f"📲 *UPI ID:* `{UPI_ID}`\n\n"
        f"How much do you want to deposit? (enter number in ₹)\n"
        f"Example: `50` for ₹50 = 50 points"
    )
    await update.message.reply_text(text, parse_mode="Markdown")
    return AWAIT_AMOUNT

async def deposit_amount(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        amt = float(update.message.text.strip())
        if amt < MIN_DEPOSIT:
            await update.message.reply_text(f"❌ Minimum deposit is ₹{MIN_DEPOSIT}. Try again:")
            return AWAIT_AMOUNT
        ctx.user_data['deposit_amount'] = amt
        await update.message.reply_text(
            f"✅ Amount: ₹{amt:.0f} = {int(amt)} points\n\n"
            f"📲 Pay *₹{amt:.0f}* to UPI: `{UPI_ID}`\n\n"
            f"After payment, send your *12-digit UTR/Transaction ID*:",
            parse_mode="Markdown")
        return AWAIT_UTR
    except ValueError:
        await update.message.reply_text("❌ Invalid amount. Enter a number like `50`:", parse_mode="Markdown")
        return AWAIT_AMOUNT

async def deposit_utr(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    utr = update.message.text.strip()
    if len(utr) < 8:
        await update.message.reply_text("❌ UTR/Transaction ID looks too short. Please check and resend:")
        return AWAIT_UTR
    u = ensure_user(update)
    amt = ctx.user_data.get('deposit_amount', 0)
    pts = int(amt)
    with get_db() as db:
        # Check duplicate UTR
        dup = db.execute("SELECT id FROM deposits WHERE utr=?", (utr,)).fetchone()
        if dup:
            await update.message.reply_text("⚠️ This UTR has already been submitted. Contact admin if needed.")
            return ConversationHandler.END
        db.execute(
            "INSERT INTO deposits (user_id,amount_inr,points,utr) VALUES (?,?,?,?)",
            (u['user_id'], amt, pts, utr))
        dep_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    await update.message.reply_text(
        f"✅ *Deposit Request Submitted!*\n\n"
        f"💵 Amount: ₹{amt:.0f}\n"
        f"🪙 Points: {pts}\n"
        f"🔖 UTR: `{utr}`\n\n"
        f"⏳ Admin will verify and credit your account within a few minutes.",
        parse_mode="Markdown", reply_markup=MAIN_KB)

    # Notify admin
    if ADMIN_ID:
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ Approve", callback_data=f"dep_approve_{dep_id}"),
            InlineKeyboardButton("❌ Reject",  callback_data=f"dep_reject_{dep_id}"),
        ]])
        try:
            await ctx.bot.send_message(ADMIN_ID,
                f"🔔 *New Deposit Request* #{dep_id}\n"
                f"👤 User: {u['full_name']} (ID: {u['user_id']})\n"
                f"💰 Amount: ₹{amt:.0f} → {pts} pts\n"
                f"🔖 UTR: `{utr}`",
                parse_mode="Markdown", reply_markup=kb)
        except Exception as e:
            log.warning(f"Could not notify admin: {e}")

    ctx.user_data.clear()
    return ConversationHandler.END

async def deposit_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data.clear()
    await update.message.reply_text("❌ Deposit cancelled.", reply_markup=MAIN_KB)
    return ConversationHandler.END

# ── Admin: Approve / Reject Deposit ──────────────────────────────────────────
async def admin_deposit_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if update.effective_user.id != ADMIN_ID:
        await q.answer("⛔ Admin only", show_alert=True); return

    parts = q.data.split("_")   # dep_approve_ID or dep_reject_ID
    action = parts[1]
    dep_id = int(parts[2])

    with get_db() as db:
        dep = db.execute("SELECT * FROM deposits WHERE id=?", (dep_id,)).fetchone()
        if not dep:
            await q.edit_message_text("❌ Deposit not found."); return
        if dep['status'] != 'pending':
            await q.edit_message_text(f"ℹ️ Already {dep['status']}."); return

        if action == "approve":
            db.execute("UPDATE deposits SET status='approved', processed_at=datetime('now') WHERE id=?", (dep_id,))
            db.execute("UPDATE users SET points=points+?, total_deposited=total_deposited+? WHERE user_id=?",
                       (dep['points'], dep['amount_inr'], dep['user_id']))
            db.execute("INSERT INTO txn_log(user_id,type,amount,note) VALUES(?,?,?,?)",
                       (dep['user_id'], 'deposit', dep['points'], f"Deposit #{dep_id} approved"))
            await q.edit_message_text(
                f"✅ Deposit #{dep_id} *APPROVED*\n💰 ₹{dep['amount_inr']:.0f} → {dep['points']} pts credited",
                parse_mode="Markdown")
            try:
                await ctx.bot.send_message(dep['user_id'],
                    f"🎉 *Deposit Approved!*\n"
                    f"💰 ₹{dep['amount_inr']:.0f} → {fmt_pts(dep['points'])} added to your wallet!\n"
                    f"Happy predicting! 🎯",
                    parse_mode="Markdown")
            except: pass

        else:  # reject
            db.execute("UPDATE deposits SET status='rejected', processed_at=datetime('now') WHERE id=?", (dep_id,))
            await q.edit_message_text(f"❌ Deposit #{dep_id} *REJECTED*", parse_mode="Markdown")
            try:
                await ctx.bot.send_message(dep['user_id'],
                    f"❌ *Deposit Rejected* (#{dep_id})\n"
                    f"UTR: {dep['utr']}\n"
                    f"Please contact admin if this is an error.",
                    parse_mode="Markdown")
            except: pass

# ── Markets ───────────────────────────────────────────────────────────────────
async def cmd_markets(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ensure_user(update)
    with get_db() as db:
        markets = db.execute(
            "SELECT * FROM markets WHERE status='open' ORDER BY id DESC LIMIT 10").fetchall()
    if not markets:
        await update.message.reply_text(
            "📊 No open markets right now.\nCheck back soon! 🕐")
        return
    for m in markets:
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton(f"✅ {m['option_yes']}", callback_data=f"bet_{m['id']}_YES"),
            InlineKeyboardButton(f"❌ {m['option_no']}", callback_data=f"bet_{m['id']}_NO"),
        ]])
        await update.message.reply_text(
            market_card(m), parse_mode="Markdown", reply_markup=kb)

# ── Bet Placement ─────────────────────────────────────────────────────────────
BET_STATE = {}  # simple in-memory state: user_id → {market_id, choice}

async def bet_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    u = ensure_user(update)
    parts = q.data.split("_")   # bet_MARKETID_CHOICE
    market_id = int(parts[1])
    choice    = parts[2]

    with get_db() as db:
        m = db.execute("SELECT * FROM markets WHERE id=?", (market_id,)).fetchone()
    if not m or m['status'] != 'open':
        await q.edit_message_text("❌ Market is closed or not found."); return

    BET_STATE[u['user_id']] = {'market_id': market_id, 'choice': choice}
    ctx.user_data['betting'] = True

    await q.edit_message_text(
        f"🎯 *Place Prediction*\n"
        f"Market: _{m['question']}_\n"
        f"Your pick: *{choice}* ({'✅' if choice=='YES' else '❌'})\n\n"
        f"💰 Your balance: {fmt_pts(u['points'])}\n\n"
        f"How many points to bet? (minimum 1)\n"
        f"Reply with a number:",
        parse_mode="Markdown")

async def bet_amount_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in BET_STATE:
        return   # not in betting flow

    u = ensure_user(update)
    state = BET_STATE[uid]

    try:
        pts = float(update.message.text.strip())
    except ValueError:
        await update.message.reply_text("❌ Enter a valid number of points:"); return

    if pts < 1:
        await update.message.reply_text("❌ Minimum bet is 1 point."); return
    if pts > u['points']:
        await update.message.reply_text(
            f"❌ Insufficient balance!\nYour balance: {fmt_pts(u['points'])}"); return

    market_id = state['market_id']
    choice    = state['choice']

    with get_db() as db:
        m = db.execute("SELECT * FROM markets WHERE id=?", (market_id,)).fetchone()
        if not m or m['status'] != 'open':
            await update.message.reply_text("❌ Market closed."); del BET_STATE[uid]; return

        # Deduct points, record bet
        db.execute("UPDATE users SET points=points-? WHERE user_id=?", (pts, uid))
        db.execute("INSERT INTO bets(user_id,market_id,choice,points) VALUES(?,?,?,?)",
                   (uid, market_id, choice, pts))
        pool_col = 'pool_yes' if choice == 'YES' else 'pool_no'
        db.execute(f"UPDATE markets SET {pool_col}={pool_col}+? WHERE id=?", (pts, market_id))
        db.execute("INSERT INTO txn_log(user_id,type,amount,note) VALUES(?,?,?,?)",
                   (uid, 'bet', -pts, f"Bet on market #{market_id} → {choice}"))
        m_updated = db.execute("SELECT * FROM markets WHERE id=?", (market_id,)).fetchone()

    del BET_STATE[uid]
    py, pn = odds_display(m_updated['pool_yes'], m_updated['pool_no'])
    await update.message.reply_text(
        f"🎉 *Bet Placed!*\n"
        f"Market: _{m['question']}_\n"
        f"Pick: *{choice}*  |  Points: {fmt_pts(pts)}\n\n"
        f"📊 New odds → ✅ {py}%  |  ❌ {pn}%\n"
        f"💰 Remaining balance: {fmt_pts(u['points']-pts)}\n\n"
        f"Good luck! 🍀",
        parse_mode="Markdown", reply_markup=MAIN_KB)

# ── History ───────────────────────────────────────────────────────────────────
async def cmd_history(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    u = ensure_user(update)
    uid = u['user_id']
    with get_db() as db:
        bets = db.execute(
            "SELECT b.*, m.question FROM bets b JOIN markets m ON b.market_id=m.id "
            "WHERE b.user_id=? ORDER BY b.placed_at DESC LIMIT 10", (uid,)).fetchall()
        deps = db.execute(
            "SELECT * FROM deposits WHERE user_id=? ORDER BY requested_at DESC LIMIT 5", (uid,)).fetchall()

    lines = ["📜 *Your Recent History*\n"]

    lines.append("━━ 🎯 *Recent Bets* ━━")
    if bets:
        for b in bets:
            emoji = {"pending":"⏳","won":"🏆","lost":"💔"}.get(b['status'],"❓")
            payout = f" (+{fmt_pts(b['payout'])})" if b['status']=='won' and b['payout'] else ""
            lines.append(
                f"{emoji} *{b['question'][:35]}...*\n"
                f"   Pick: {b['choice']} | Bet: {fmt_pts(b['points'])}{payout}\n"
                f"   Status: {b['status'].upper()} | {b['placed_at'][:10]}")
    else:
        lines.append("No bets yet.")

    lines.append("\n━━ 💰 *Recent Deposits* ━━")
    if deps:
        for d in deps:
            emoji = {"pending":"⏳","approved":"✅","rejected":"❌"}.get(d['status'],"❓")
            lines.append(f"{emoji} ₹{d['amount_inr']:.0f} → {int(d['points'])} pts | {d['status'].upper()} | {d['requested_at'][:10]}")
    else:
        lines.append("No deposits yet.")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

# ── Leaderboard ───────────────────────────────────────────────────────────────
async def cmd_leaderboard(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    with get_db() as db:
        # Top by total points (balance + locked in bets)
        leaders = db.execute("""
            SELECT u.full_name, u.username, u.points,
                   COALESCE(SUM(CASE WHEN b.status='won' THEN 1 ELSE 0 END),0) as wins,
                   COALESCE(SUM(CASE WHEN b.status='lost' THEN 1 ELSE 0 END),0) as losses
            FROM users u
            LEFT JOIN bets b ON u.user_id=b.user_id
            GROUP BY u.user_id
            ORDER BY u.points DESC LIMIT 10
        """).fetchall()

    medals = ["🥇","🥈","🥉","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"]
    lines  = ["🏆 *Leaderboard — Top 10*\n"]
    for i, row in enumerate(leaders):
        name = row['full_name'] or f"@{row['username']}" or "Anonymous"
        acc  = ""
        total_games = row['wins'] + row['losses']
        if total_games > 0:
            acc = f" | {round(row['wins']/total_games*100)}% acc"
        lines.append(f"{medals[i]} *{name}* — {fmt_pts(row['points'])}{acc}")

    if not leaders:
        lines.append("No players yet!")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

# ── ADMIN COMMANDS ────────────────────────────────────────────────────────────
async def admin_only(update: Update):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("⛔ Admin only.")
        return False
    return True

async def cmd_create_market(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update): return
    # Usage: /create_market Will India win the World Cup?|YES|NO
    args = " ".join(ctx.args)
    parts = args.split("|")
    question   = parts[0].strip() if len(parts) > 0 else ""
    option_yes = parts[1].strip() if len(parts) > 1 else "YES"
    option_no  = parts[2].strip() if len(parts) > 2 else "NO"
    if not question:
        await update.message.reply_text(
            "Usage: `/create_market Question|Yes Option|No Option`\n"
            "Example: `/create_market Will BTC hit $100k?|YES|NO`",
            parse_mode="Markdown"); return
    with get_db() as db:
        db.execute("INSERT INTO markets (question,option_yes,option_no,created_by) VALUES(?,?,?,?)",
                   (question, option_yes, option_no, update.effective_user.id))
        mid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    await update.message.reply_text(
        f"✅ Market #{mid} created!\n❓ *{question}*\n✅ {option_yes} vs ❌ {option_no}",
        parse_mode="Markdown")

async def cmd_resolve(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update): return
    # /resolve MARKET_ID YES|NO
    if len(ctx.args) < 2:
        await update.message.reply_text("Usage: `/resolve <market_id> <YES|NO>`", parse_mode="Markdown"); return
    try:
        market_id = int(ctx.args[0])
        result    = ctx.args[1].upper()
        if result not in ("YES","NO"):
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Usage: `/resolve 3 YES`", parse_mode="Markdown"); return

    with get_db() as db:
        m = db.execute("SELECT * FROM markets WHERE id=?", (market_id,)).fetchone()
        if not m or m['status'] != 'open':
            await update.message.reply_text("❌ Market not found or already resolved."); return

        pool_winner = m['pool_yes'] if result == 'YES' else m['pool_no']
        pool_loser  = m['pool_no']  if result == 'YES' else m['pool_yes']
        total_pool  = m['pool_yes'] + m['pool_no']
        choice_col  = 'YES' if result == 'YES' else 'NO'

        winning_bets = db.execute(
            "SELECT * FROM bets WHERE market_id=? AND choice=? AND status='pending'",
            (market_id, choice_col)).fetchall()

        payouts_made = 0
        for bet in winning_bets:
            if pool_winner > 0:
                payout = (bet['points'] / pool_winner) * total_pool
            else:
                payout = bet['points']  # refund if no one bet on winner
            payout = round(payout, 2)
            db.execute("UPDATE bets SET status='won', payout=? WHERE id=?", (payout, bet['id']))
            db.execute("UPDATE users SET points=points+? WHERE user_id=?", (payout, bet['user_id']))
            db.execute("INSERT INTO txn_log(user_id,type,amount,note) VALUES(?,?,?,?)",
                       (bet['user_id'], 'payout', payout, f"Won market #{market_id}"))
            payouts_made += payout
            # Notify winner
            try:
                await ctx.bot.send_message(bet['user_id'],
                    f"🏆 *You Won!*\n"
                    f"Market: _{m['question']}_\n"
                    f"Result: *{result}* ✅\n"
                    f"Payout: {fmt_pts(payout)}\n"
                    f"Congrats! 🎉",
                    parse_mode="Markdown")
            except: pass

        # Mark losers
        db.execute(
            "UPDATE bets SET status='lost' WHERE market_id=? AND choice!=? AND status='pending'",
            (market_id, choice_col))

        # Close market
        db.execute("UPDATE markets SET status='resolved', result=? WHERE id=?", (result, market_id))

    await update.message.reply_text(
        f"✅ Market #{market_id} resolved as *{result}*\n"
        f"💰 Total paid out: {fmt_pts(payouts_made)}\n"
        f"🏆 Winners: {len(winning_bets)}",
        parse_mode="Markdown")

async def cmd_admin_panel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update): return
    with get_db() as db:
        users     = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        open_mkts = db.execute("SELECT COUNT(*) FROM markets WHERE status='open'").fetchone()[0]
        pending_d = db.execute("SELECT COUNT(*),COALESCE(SUM(amount_inr),0) FROM deposits WHERE status='pending'").fetchone()
        total_pts = db.execute("SELECT COALESCE(SUM(points),0) FROM users").fetchone()[0]
    await update.message.reply_text(
        f"🔧 *Admin Panel*\n"
        f"━━━━━━━━━━━━━━\n"
        f"👥 Users: {users}\n"
        f"📊 Open Markets: {open_mkts}\n"
        f"⏳ Pending Deposits: {pending_d[0]} (₹{pending_d[1]:,.0f})\n"
        f"🪙 Total Points in Circulation: {fmt_pts(total_pts)}\n"
        f"━━━━━━━━━━━━━━\n"
        f"Commands:\n"
        f"`/create_market Question|YES|NO`\n"
        f"`/resolve <id> <YES|NO>`\n"
        f"`/give_points <user_id> <points>`\n"
        f"`/all_deposits`\n"
        f"`/all_users`",
        parse_mode="Markdown")

async def cmd_give_points(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update): return
    if len(ctx.args) < 2:
        await update.message.reply_text("Usage: `/give_points <user_id> <points>`", parse_mode="Markdown"); return
    try:
        uid = int(ctx.args[0]); pts = float(ctx.args[1])
    except ValueError:
        await update.message.reply_text("❌ Invalid. Use: `/give_points 12345 100`", parse_mode="Markdown"); return
    with get_db() as db:
        u = db.execute("SELECT * FROM users WHERE user_id=?", (uid,)).fetchone()
        if not u:
            await update.message.reply_text("❌ User not found."); return
        db.execute("UPDATE users SET points=points+? WHERE user_id=?", (pts, uid))
        db.execute("INSERT INTO txn_log(user_id,type,amount,note) VALUES(?,?,?,?)",
                   (uid, 'admin_grant', pts, "Admin manual grant"))
    await update.message.reply_text(f"✅ Gave {fmt_pts(pts)} to user {uid}")
    try:
        await ctx.bot.send_message(uid, f"🎁 Admin gifted you {fmt_pts(pts)}!")
    except: pass

async def cmd_all_deposits(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update): return
    with get_db() as db:
        deps = db.execute(
            "SELECT d.*, u.full_name FROM deposits d JOIN users u ON d.user_id=u.user_id "
            "WHERE d.status='pending' ORDER BY d.requested_at DESC LIMIT 20").fetchall()
    if not deps:
        await update.message.reply_text("✅ No pending deposits!"); return
    lines = ["⏳ *Pending Deposits*\n"]
    for d in deps:
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ Approve", callback_data=f"dep_approve_{d['id']}"),
            InlineKeyboardButton("❌ Reject",  callback_data=f"dep_reject_{d['id']}"),
        ]])
        await update.message.reply_text(
            f"Deposit #{d['id']} | {d['full_name']}\n₹{d['amount_inr']:.0f} | UTR: `{d['utr']}`",
            parse_mode="Markdown", reply_markup=kb)

async def cmd_all_users(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await admin_only(update): return
    with get_db() as db:
        users = db.execute(
            "SELECT * FROM users ORDER BY points DESC LIMIT 20").fetchall()
    lines = ["👥 *All Users*\n"]
    for u in users:
        lines.append(f"• {u['full_name']} (ID:{u['user_id']}) | {fmt_pts(u['points'])}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

# ── Text Router ───────────────────────────────────────────────────────────────
async def text_router(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    txt = update.message.text
    if txt == "📊 Markets":       await cmd_markets(update, ctx)
    elif txt == "💰 Deposit":     await cmd_deposit(update, ctx)
    elif txt == "👛 My Balance":  await cmd_balance(update, ctx)
    elif txt == "📜 History":     await cmd_history(update, ctx)
    elif txt == "🏆 Leaderboard": await cmd_leaderboard(update, ctx)
    elif txt == "🆘 Help":        await cmd_help(update, ctx)
    elif ctx.user_data.get('betting') or update.effective_user.id in BET_STATE:
        await bet_amount_handler(update, ctx)

# ── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    init_db()
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # Deposit conversation
    deposit_conv = ConversationHandler(
        entry_points=[
            CommandHandler("deposit", cmd_deposit),
            MessageHandler(filters.Regex("^💰 Deposit$"), cmd_deposit),
        ],
        states={
            AWAIT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, deposit_amount)],
            AWAIT_UTR:    [MessageHandler(filters.TEXT & ~filters.COMMAND, deposit_utr)],
        },
        fallbacks=[CommandHandler("cancel", deposit_cancel)],
        allow_reentry=True,
    )

    app.add_handler(deposit_conv)
    app.add_handler(CommandHandler("start",         cmd_start))
    app.add_handler(CommandHandler("help",          cmd_help))
    app.add_handler(CommandHandler("balance",       cmd_balance))
    app.add_handler(CommandHandler("markets",       cmd_markets))
    app.add_handler(CommandHandler("history",       cmd_history))
    app.add_handler(CommandHandler("leaderboard",   cmd_leaderboard))
    app.add_handler(CommandHandler("admin",         cmd_admin_panel))
    app.add_handler(CommandHandler("create_market", cmd_create_market))
    app.add_handler(CommandHandler("resolve",       cmd_resolve))
    app.add_handler(CommandHandler("give_points",   cmd_give_points))
    app.add_handler(CommandHandler("all_deposits",  cmd_all_deposits))
    app.add_handler(CommandHandler("all_users",     cmd_all_users))
    app.add_handler(CallbackQueryHandler(bet_callback,          pattern="^bet_"))
    app.add_handler(CallbackQueryHandler(admin_deposit_callback, pattern="^dep_"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_router))

    log.info("🤖 PredictBot is running...")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
